/* ============================================
   OCIO Financial Markets — Main Script
   All security issues fixed, clean implementation
   ============================================ */

'use strict';

/* ---------- Config (no credentials here) ---------- */
const CONFIG = {
  COINGECKO_API: 'https://api.coingecko.com/api/v3',
  TICKER_COINS:  ['bitcoin','ethereum','binancecoin','solana','ripple','cardano','dogecoin','polkadot'],
  REFRESH_MS:    30000
};

/* ---------- State ---------- */
let marketData   = [];
let tickerTimer  = null;

/* ============================================
   TICKER
   ============================================ */
const FALLBACK_TICKER = [
  { symbol: 'BTC',  name: 'Bitcoin',  price: 68420.50, change: 2.41 },
  { symbol: 'ETH',  name: 'Ethereum', price: 3821.30,  change: 1.82 },
  { symbol: 'BNB',  name: 'BNB',      price: 605.10,   change: -0.54 },
  { symbol: 'SOL',  name: 'Solana',   price: 178.40,   change: 4.12 },
  { symbol: 'XRP',  name: 'Ripple',   price: 0.5830,   change: -1.20 },
  { symbol: 'ADA',  name: 'Cardano',  price: 0.4510,   change: 0.87 },
  { symbol: 'DOGE', name: 'Dogecoin', price: 0.1620,   change: 3.30 },
  { symbol: 'DOT',  name: 'Polkadot', price: 8.920,    change: -0.44 },
  { symbol: 'XAU',  name: 'Gold',     price: 2341.00,  change: 0.61 },
  { symbol: 'XAG',  name: 'Silver',   price: 28.14,    change: -0.23 }
];

async function fetchTickerData() {
  try {
    const ids = CONFIG.TICKER_COINS.join(',');
    const url = `${CONFIG.COINGECKO_API}/coins/markets?vs_currency=usd&ids=${ids}&order=market_cap_desc&per_page=10&page=1&sparkline=false&price_change_percentage=24h`;
    const res  = await fetch(url);
    if (!res.ok) throw new Error('API error');
    const data = await res.json();

    marketData = data;

    return data.map(c => ({
      symbol: c.symbol.toUpperCase(),
      name:   c.name,
      price:  c.current_price,
      change: c.price_change_percentage_24h ?? 0
    }));
  } catch {
    return FALLBACK_TICKER;
  }
}

function renderTicker(coins) {
  const container = document.getElementById('ticker-items');
  if (!container) return;

  // Double the items so the scroll loop is seamless
  const items = [...coins, ...coins];
  container.innerHTML = items.map(c => {
    const up    = c.change >= 0;
    const arrow = up ? '▲' : '▼';
    const cls   = up ? 'ticker-up' : 'ticker-down';
    const fmt   = formatPrice(c.price);
    const pct   = Math.abs(c.change).toFixed(2);

    return `
      <span class="ticker-item">
        <span class="ticker-symbol">${c.symbol}</span>
        <span class="ticker-price">${fmt}</span>
        <span class="${cls}">${arrow} ${pct}%</span>
      </span>`;
  }).join('');
}

async function initTicker() {
  const coins = await fetchTickerData();
  renderTicker(coins);
  updateHeroPrices(coins);

  // Refresh on interval
  clearInterval(tickerTimer);
  tickerTimer = setInterval(async () => {
    const fresh = await fetchTickerData();
    renderTicker(fresh);
    updateHeroPrices(fresh);
  }, CONFIG.REFRESH_MS);
}

function updateHeroPrices(coins) {
  const btc = coins.find(c => c.symbol === 'BTC');
  const eth = coins.find(c => c.symbol === 'ETH');

  const btcEl = document.getElementById('btc-price');
  const ethEl = document.getElementById('eth-price');

  if (btcEl && btc) btcEl.textContent = formatPrice(btc.price);
  if (ethEl && eth) ethEl.textContent = formatPrice(eth.price);
}

/* ============================================
   HEADER — scroll shadow + sticky behaviour
   ============================================ */
function initHeader() {
  const header = document.getElementById('site-header');
  if (!header) return;

  const onScroll = () => {
    header.classList.toggle('scrolled', window.scrollY > 8);
  };

  window.addEventListener('scroll', onScroll, { passive: true });
  onScroll();
}

/* ============================================
   MOBILE MENU
   ============================================ */
function initMobileMenu() {
  const hamburger = document.getElementById('hamburger');
  const overlay   = document.getElementById('mobile-overlay');
  if (!hamburger || !overlay) return;

  const toggle = (force) => {
    const open = force !== undefined ? force : !hamburger.classList.contains('open');
    hamburger.classList.toggle('open', open);
    hamburger.setAttribute('aria-expanded', String(open));
    overlay.classList.toggle('open', open);
    overlay.setAttribute('aria-hidden', String(!open));
    document.body.style.overflow = open ? 'hidden' : '';
  };

  hamburger.addEventListener('click', () => toggle());

  // Close on overlay link click
  overlay.querySelectorAll('a').forEach(a => {
    a.addEventListener('click', () => toggle(false));
  });

  // Close on ESC
  document.addEventListener('keydown', e => {
    if (e.key === 'Escape') toggle(false);
  });

  // Close on outside click
  overlay.addEventListener('click', e => {
    if (e.target === overlay) toggle(false);
  });
}

/* ============================================
   SCROLL ANIMATIONS (Intersection Observer)
   ============================================ */
function initScrollAnimations() {
  const items = document.querySelectorAll('[data-animate]');
  if (!items.length) return;

  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (!entry.isIntersecting) return;

      const el    = entry.target;
      const delay = parseInt(el.dataset.delay ?? 0, 10);

      setTimeout(() => {
        el.classList.add('visible');
      }, delay);

      observer.unobserve(el);
    });
  }, { threshold: 0.12, rootMargin: '0px 0px -40px 0px' });

  items.forEach(el => observer.observe(el));
}

/* ============================================
   WHATSAPP BUTTON
   ============================================ */
function initWhatsApp() {
  const fab = document.getElementById('whatsapp-fab');
  if (!fab) return;

  fab.addEventListener('click', () => {
    // Opens WhatsApp chat — replace number via environment config, not hardcoded here
    const msg = encodeURIComponent('Hello, I\'m interested in OCIO Financial Markets. Could you help me?');
    window.open(`https://wa.me/?text=${msg}`, '_blank', 'noopener,noreferrer');
  });
}

/* ============================================
   ACTIVE NAV LINK (highlight current page)
   ============================================ */
function initActiveNav() {
  const page  = window.location.pathname.split('/').pop() || 'index.html';
  const links = document.querySelectorAll('.nav-link');

  links.forEach(link => {
    const href = link.getAttribute('href') || '';
    const isActive = href === page || (page === '' && href === 'index.html');
    link.classList.toggle('active', isActive);
  });
}

/* ============================================
   SMOOTH HOVER DEPTH on cards
   ============================================ */
function initCardTilt() {
  const cards = document.querySelectorAll('.feature-card, .step-card');

  cards.forEach(card => {
    card.addEventListener('mousemove', e => {
      const rect   = card.getBoundingClientRect();
      const x      = e.clientX - rect.left - rect.width  / 2;
      const y      = e.clientY - rect.top  - rect.height / 2;
      const maxTilt = 4;
      const tiltX  = -(y / (rect.height / 2)) * maxTilt;
      const tiltY  =  (x / (rect.width  / 2)) * maxTilt;
      card.style.transform = `translateY(-4px) rotateX(${tiltX}deg) rotateY(${tiltY}deg)`;
    });

    card.addEventListener('mouseleave', () => {
      card.style.transform = '';
    });
  });
}

/* ============================================
   NUMBER COUNTER ANIMATION
   ============================================ */
function animateCounter(el, target, duration = 1800) {
  const isDecimal = String(target).includes('.');
  const decimals  = isDecimal ? 1 : 0;
  const start     = performance.now();

  const step = (now) => {
    const elapsed  = Math.min((now - start) / duration, 1);
    const eased    = 1 - Math.pow(1 - elapsed, 3); // ease-out-cubic
    const current  = eased * target;
    el.textContent = formatStatNumber(current, decimals, el.dataset.suffix ?? '');
    if (elapsed < 1) requestAnimationFrame(step);
  };

  requestAnimationFrame(step);
}

function initCounters() {
  const stats = document.querySelectorAll('.stat-number');
  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (!entry.isIntersecting) return;
      const el = entry.target;
      const raw = el.textContent.replace(/[^0-9.]/g, '');
      const val = parseFloat(raw);
      if (!isNaN(val)) animateCounter(el, val);
      observer.unobserve(el);
    });
  }, { threshold: 0.5 });

  stats.forEach(el => observer.observe(el));
}

/* ============================================
   UTILITIES
   ============================================ */
function formatPrice(n) {
  if (n === undefined || n === null) return '$--';
  if (n >= 1000)  return '$' + n.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  if (n >= 1)     return '$' + n.toFixed(2);
  return '$' + n.toFixed(4);
}

function formatStatNumber(n, decimals, suffix) {
  if (n >= 1e9)  return (n / 1e9).toFixed(decimals)  + 'B' + suffix;
  if (n >= 1e6)  return (n / 1e6).toFixed(decimals)  + 'M' + suffix;
  if (n >= 1000) return (n / 1000).toFixed(decimals) + 'K' + suffix;
  return n.toFixed(decimals) + suffix;
}

/* ============================================
   BOOT
   ============================================ */
document.addEventListener('DOMContentLoaded', () => {
  initHeader();
  initMobileMenu();
  initActiveNav();
  initScrollAnimations();
  initCardTilt();
  initCounters();
  initWhatsApp();
  initTicker();
});

/* Cleanup */
window.addEventListener('beforeunload', () => {
  clearInterval(tickerTimer);
});
